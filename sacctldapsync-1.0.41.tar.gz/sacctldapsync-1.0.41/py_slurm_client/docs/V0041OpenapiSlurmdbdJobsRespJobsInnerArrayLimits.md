# V0041OpenapiSlurmdbdJobsRespJobsInnerArrayLimits


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**max** | [**V0041OpenapiSlurmdbdJobsRespJobsInnerArrayLimitsMax**](V0041OpenapiSlurmdbdJobsRespJobsInnerArrayLimitsMax.md) |  | [optional] 

## Example

```python
from openapi_client.models.v0041_openapi_slurmdbd_jobs_resp_jobs_inner_array_limits import V0041OpenapiSlurmdbdJobsRespJobsInnerArrayLimits

# TODO update the JSON string below
json = "{}"
# create an instance of V0041OpenapiSlurmdbdJobsRespJobsInnerArrayLimits from a JSON string
v0041_openapi_slurmdbd_jobs_resp_jobs_inner_array_limits_instance = V0041OpenapiSlurmdbdJobsRespJobsInnerArrayLimits.from_json(json)
# print the JSON string representation of the object
print(V0041OpenapiSlurmdbdJobsRespJobsInnerArrayLimits.to_json())

# convert the object into a dict
v0041_openapi_slurmdbd_jobs_resp_jobs_inner_array_limits_dict = v0041_openapi_slurmdbd_jobs_resp_jobs_inner_array_limits_instance.to_dict()
# create an instance of V0041OpenapiSlurmdbdJobsRespJobsInnerArrayLimits from a dict
v0041_openapi_slurmdbd_jobs_resp_jobs_inner_array_limits_from_dict = V0041OpenapiSlurmdbdJobsRespJobsInnerArrayLimits.from_dict(v0041_openapi_slurmdbd_jobs_resp_jobs_inner_array_limits_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


