# V0041OpenapiSlurmdbdJobsRespJobsInnerStepsInnerStatisticsEnergy


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**consumed** | [**V0041OpenapiSlurmdbdJobsRespJobsInnerStepsInnerStatisticsEnergyConsumed**](V0041OpenapiSlurmdbdJobsRespJobsInnerStepsInnerStatisticsEnergyConsumed.md) |  | [optional] 

## Example

```python
from openapi_client.models.v0041_openapi_slurmdbd_jobs_resp_jobs_inner_steps_inner_statistics_energy import V0041OpenapiSlurmdbdJobsRespJobsInnerStepsInnerStatisticsEnergy

# TODO update the JSON string below
json = "{}"
# create an instance of V0041OpenapiSlurmdbdJobsRespJobsInnerStepsInnerStatisticsEnergy from a JSON string
v0041_openapi_slurmdbd_jobs_resp_jobs_inner_steps_inner_statistics_energy_instance = V0041OpenapiSlurmdbdJobsRespJobsInnerStepsInnerStatisticsEnergy.from_json(json)
# print the JSON string representation of the object
print(V0041OpenapiSlurmdbdJobsRespJobsInnerStepsInnerStatisticsEnergy.to_json())

# convert the object into a dict
v0041_openapi_slurmdbd_jobs_resp_jobs_inner_steps_inner_statistics_energy_dict = v0041_openapi_slurmdbd_jobs_resp_jobs_inner_steps_inner_statistics_energy_instance.to_dict()
# create an instance of V0041OpenapiSlurmdbdJobsRespJobsInnerStepsInnerStatisticsEnergy from a dict
v0041_openapi_slurmdbd_jobs_resp_jobs_inner_steps_inner_statistics_energy_from_dict = V0041OpenapiSlurmdbdJobsRespJobsInnerStepsInnerStatisticsEnergy.from_dict(v0041_openapi_slurmdbd_jobs_resp_jobs_inner_steps_inner_statistics_energy_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


